function [ xx, yy, xy ] = getM( img, std )

% TODO calc image gradients

% TODO create gaussian kernel

% TODO calc tensor content and convolve it with Gaussian kernel

end
