function [ velx, vely ] = getFlow( img, img2, std )

% TODO calc image gradients

% TODO calc "time" gradient

% TODO create gaussian kernel

% TODO calc tensor content and convolve it with Gaussian kernel

% TODO calc flow (with loop this time).

end

