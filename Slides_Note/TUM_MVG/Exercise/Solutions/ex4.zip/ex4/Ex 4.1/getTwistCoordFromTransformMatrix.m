function xi = getTwistCoordFromTransformMatrix(g)
    % TO IMPLEMENT (exercise 4.1.c)
end