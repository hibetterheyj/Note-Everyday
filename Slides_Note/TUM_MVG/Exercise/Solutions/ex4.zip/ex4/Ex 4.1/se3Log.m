function [ twist ] = se3Log( T )
    % TO IMPLEMENT (exercise 4.1.d)
end