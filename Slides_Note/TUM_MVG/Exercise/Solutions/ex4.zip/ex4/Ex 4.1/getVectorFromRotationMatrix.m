function w = getVectorFromRotationMatrix(R)
    % TO IMPLEMENT (exercise 4.1.b, compare Lecture-Slides 2, Slide 13)
end