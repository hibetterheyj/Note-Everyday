function R = getRotationMatrixFromVector(w)
    % TO IMPLEMENT (exercise 4.1.a)
end