function [ T ] = se3Exp( twist )
    % TO IMPLEMENT (exercise 4.1.d)
end