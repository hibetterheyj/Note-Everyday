function V = getTransformMatrixFromTwistCoord(twCoord)
    % TO IMPLEMENT (exercise 4.1.c)
end